Compilation on hadoop:
g++ -std=c++11 main.cpp StorageBufferManager.cpp -g -o main.out
To run:
./main.out
